package com.microservices.notification_service.event;


public record Book(
        Integer bookId,
        String bookName,
        String bookAuthor) {
}