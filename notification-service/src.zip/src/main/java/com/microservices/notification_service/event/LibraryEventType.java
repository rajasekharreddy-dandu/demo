package com.microservices.notification_service.event;

public enum LibraryEventType {
    NEW,
    UPDATE
}
