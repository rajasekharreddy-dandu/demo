package com.microservices.notification_service.controller;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.microservices.notification_service.event.LibraryEvent;
import com.microservices.notification_service.service.KafkaMessagePublisher;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
public class LibraryEventController {
    @Autowired
    private  KafkaMessagePublisher kafkaMessagePublisher;


    @PostMapping("/v1/libraryEvent")
    public ResponseEntity<LibraryEvent> postMethodName(@RequestBody LibraryEvent libraryEvent) throws JsonProcessingException, ExecutionException, InterruptedException, TimeoutException {
       log.info("libraryEvent :{} ",libraryEvent);
        // kafkaMessagePublisher.sendLibraryEvent(libraryEvent);
        // kafkaMessagePublisher.sendLibraryEvent_approach2(libraryEvent);
        kafkaMessagePublisher.sendLibraryEvent_approach3(libraryEvent);

        log.info("After sending libraryevent");
        return ResponseEntity.status(HttpStatus.CREATED).body(libraryEvent);
    }
    
}
