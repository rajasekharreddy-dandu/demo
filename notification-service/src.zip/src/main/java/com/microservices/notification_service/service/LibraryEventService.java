package com.microservices.notification_service.service;

import java.util.Optional;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.RecoverableDataAccessException;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microservices.notification_service.entity.LibraryEvent;
import com.microservices.notification_service.repository.LibraryEventRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LibraryEventService {

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    private LibraryEventRepository libraryEventRepo;

    public void processLibraryEvent(ConsumerRecord<Integer, String> consumerRecord) throws JsonMappingException, JsonProcessingException{
        LibraryEvent libraryEvent=objectMapper.readValue(consumerRecord.value(),LibraryEvent.class);
        log.info("LibraryEvent {}",libraryEvent);
        if(libraryEvent!=null && libraryEvent.getLibraryEventId()==999){
            throw new RecoverableDataAccessException("Temporary server issue");
        }
        
        switch(libraryEvent.getLibraryEventType()){
            case NEW:
                //save operation
                save(libraryEvent);
                break;
            case UPDATE:
                validate(libraryEvent);
                save(libraryEvent);
                break;
            default:
                log.info("Invalid LibraryEvent type");
        }
    }

    private void validate(LibraryEvent libraryEvent) {
       
        if(libraryEvent.getLibraryEventId()==null){
            log.error("Library Event Id is missing");
            throw new IllegalArgumentException("Library Event Id is missing");
            
        }
       Optional<LibraryEvent> optionalLibraryEvent = libraryEventRepo.findById(libraryEvent.getLibraryEventId());
       
       if(!optionalLibraryEvent.isPresent()){
        throw new IllegalArgumentException("Not a valid Library event");
       }

       log.info("Validation is successfull for Library Event {}",optionalLibraryEvent.get());
    }

    private void save(LibraryEvent libraryEvent) {
        libraryEvent.getBook().setLibraryEvent(libraryEvent);
        libraryEventRepo.save(libraryEvent);
        log.info("Successfully persist the library Event {}",libraryEvent);
    }
    
}
