package com.microservices.notification_service.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservices.notification_service.entity.LibraryEvent;

public interface LibraryEventRepository extends CrudRepository<LibraryEvent, Integer>{

}
