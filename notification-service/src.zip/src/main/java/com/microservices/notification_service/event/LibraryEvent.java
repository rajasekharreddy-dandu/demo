package com.microservices.notification_service.event;

public record LibraryEvent(
        Integer libraryEventId,
        LibraryEventType libraryEventType,
        // @NotNull
        // @Valid
        Book book
) {
}