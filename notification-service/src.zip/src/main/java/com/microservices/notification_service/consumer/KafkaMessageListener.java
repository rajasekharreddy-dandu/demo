package com.microservices.notification_service.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microservices.notification_service.event.Customer;
import com.microservices.notification_service.event.OrderPlacedEvent;

@Component
public class KafkaMessageListener {

    Logger log = LoggerFactory.getLogger(KafkaMessageListener.class);

    @KafkaListener(topics = "notificationTopic",groupId="notificationId")
    public void handleNotification(ConsumerRecord<String, String> record) throws JsonMappingException, JsonProcessingException{
		log.info("consumer consume the events {} ", record);
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = record.value(); // Get the string value from the consumer record
        OrderPlacedEvent orderPlacedEvent = objectMapper.readValue(jsonString, OrderPlacedEvent.class);
        System.out.println("Recieved Notification from order - "+jsonString);
		// log.info("Recieved Notification from order - {}",orderPlacedEvent.getOrderNumber());
	}

   @KafkaListener(topics = "javatechie-demo",groupId = "jt-group-new")
   public void consumeEvent(ConsumerRecord<String, String> record) throws JsonMappingException, JsonProcessingException{
		log.info("consumer consume the events {} ", record);
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = record.value(); // Get the string value from the consumer record
        Customer customer = objectMapper.readValue(jsonString, Customer.class);
    //     System.out.println("Recieved Notification from order - "+jsonString);
		log.info("Recieved Notification from Customer - {}",customer.getContactNo());
   }
//
//    @KafkaListener(topics = "javatechie-demo1",groupId = "jt-group-new")
//    public void consume3(String message) {
//        log.info("consumer3 consume the message {} ", message);
//    }
//
//    @KafkaListener(topics = "javatechie-demo1",groupId = "jt-group-new")
//    public void consume4(String message) {
//        log.info("consumer4 consume the message {} ", message);
//    }
}