package com.microservices.notification_service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@WebMvcTest(LibrarayEventControllerTest.class)
public class LibrarayEventControllerTest {
    @Autowired
    MockMvc mockMvc;

    @Test
    void postLibrarayEvent(){

        // mockMvc.perform(MockMvcRequestBuilders.post("/v1/libraryEvent").
        
        // );
    }
}
