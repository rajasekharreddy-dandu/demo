package com.microservices.order_service.service;

import java.util.List;
import java.util.UUID;
import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;

import com.microservices.order_service.dto.InventoryResponse;
import com.microservices.order_service.dto.OrderLineItemsDto;
import com.microservices.order_service.dto.OrderRequest;
import com.microservices.order_service.entity.OrderPre;
import com.microservices.order_service.entity.OrderLineItems;
import com.microservices.order_service.event.OrderPlacedEvent;
import com.microservices.order_service.repository.OrderPreRepository;

import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class OrderPreService {

    private final OrderPreRepository orderRepository;
    private final WebClient.Builder webClientBuilder;
    private final Tracer tracer;
    private final KafkaTemplate<String,OrderPlacedEvent> kafkaTemplate;

    private static final Log logger = LogFactory.getLog(OrderPreService.class);


    public String placeOrder(OrderRequest orderRequest){
        System.out.println(orderRequest.getOrderLineItemsDtoList());
        OrderPre order=new OrderPre();
        order.setOrderNumber(UUID.randomUUID().toString());
       List<OrderLineItems> orderLineItems = orderRequest.getOrderLineItemsDtoList()
                    .stream()
                    .map(orderLineItemDto->mapToDto(orderLineItemDto))
                    .toList();
        order.setOrederLineItemsList(orderLineItems);

        List<String> skucodes= order.getOrederLineItemsList().stream()
                    .map(OrderLineItems::getSkuCode).toList();

        Span inventoryServiceLookup = tracer.nextSpan().name("Inventory-service-lookup");
        try(Tracer.SpanInScope spanInScope = tracer.withSpan(inventoryServiceLookup.start())){
             // Call Inventory service , and place order if product is in stock
            InventoryResponse[] inventoryResponseArray =webClientBuilder.build().get()
            .uri("http://Inventory-Service/api/inventory",uriBuilder->uriBuilder.queryParam("skuCode", skucodes).build())
            .retrieve()
            .bodyToMono(InventoryResponse[].class)
            .block();
            boolean allProductsInStock =Arrays.stream(inventoryResponseArray).peek(System.out::println).allMatch(InventoryResponse::isInStock);
            if(allProductsInStock){
                orderRepository.save(order);
                kafkaTemplate.send("notificationTopic", new OrderPlacedEvent(order.getOrderNumber()));
                return "Order placed successfully";
            }else{
                throw new IllegalArgumentException("Product is not in stock,Please try again later");
            }
        }finally{
            inventoryServiceLookup.end();
        }
       

        
    } 

    public OrderLineItems mapToDto(OrderLineItemsDto orderLineitemsDto){
        OrderLineItems orderLineItems=new OrderLineItems();
        orderLineItems.setPrice(orderLineitemsDto.getPrice());
        orderLineItems.setSkuCode(orderLineitemsDto.getSkuCode());
        orderLineItems.setQuantity(orderLineitemsDto.getQuantity());

        return orderLineItems;
    }
}
