package com.microservices.order_service.dto.order;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.microservices.order_service.dto.user.UserDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Data
@Builder
public class CartDto implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;
    @Schema(name="cartId",description="Cart Id",example="1")
    private Integer cartId;

    @Schema(description="User Id",example="1234")
    // @NotNull
    private Long userId;

    // @Schema(description="Order Details", implementation = OrderDto.class)
    @JsonProperty("order")
    @JsonInclude(Include.NON_NULL)
    private Set<OrderDto> orderDtos;

    // @Schema(description="User Details", implementation = UserDto.class)
    @JsonProperty("user")
    @JsonInclude(Include.NON_NULL)
    private UserDto userDto;

}