package com.microservices.order_service.dto.product;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class CategoryDto implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;
    @Schema(description="Category Id", example="1" )
    private Integer categoryId;
    @Schema(description="Category Title", example="Electronic Accessories" )
    private String categoryTitle;
    @Schema(description="Category  Img Url", example="https://categories.com/category/electronic_accessories.jpeg" )
    private String imageUrl;
    // @Schema(description="SubCategory Details", implementation = CategoryDto.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Set<CategoryDto> subCategoriesDtos;

    // @Schema(description="Parent Category Details", implementation = CategoryDto.class)
    @JsonProperty("parentCategory")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private CategoryDto parentCategoryDto;

    // @Schema(description="Product Details", implementation = ProductDto.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Set<ProductDto> productDtos;

}
