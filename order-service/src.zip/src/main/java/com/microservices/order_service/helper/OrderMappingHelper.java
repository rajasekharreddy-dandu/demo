package com.microservices.order_service.helper;

import com.microservices.order_service.dto.order.CartDto;
import com.microservices.order_service.dto.order.OrderDto;
import com.microservices.order_service.dto.product.ProductDto;
import com.microservices.order_service.entity.Cart;
import com.microservices.order_service.entity.Order;

public interface OrderMappingHelper {
    static OrderDto map(Order order) {
        if (order == null) return null;
        
        CartDto cartDto = null;
        if (order.getCart() != null) {
                cartDto = CartDto.builder()
                .cartId(order.getCart().getCartId())
                .userId(order.getCart().getUserId())
                .build();
        }

        return OrderDto.builder()
                .orderId(order.getOrderId())
                .orderDate(order.getOrderDate())
                .orderDesc(order.getOrderDesc())
                .orderFee(order.getOrderFee())
                .productId(order.getProductId())
                .cartDto(cartDto)
                .build();
    }

    static Order map(final OrderDto orderDto) {
        if (orderDto == null) return null;
        Cart cart = null;
        if (orderDto.getCartDto() != null) {
                cart = Cart.builder()
                .cartId(orderDto.getCartDto().getCartId())
                .userId(orderDto.getCartDto().getUserId())
                .build();
        }

        return Order.builder()
                .orderId(orderDto.getOrderId())
                .orderDate(orderDto.getOrderDate())
                .orderDesc(orderDto.getOrderDesc())
                .orderFee(orderDto.getOrderFee())
                .productId(orderDto.getProductId())
                .cart(cart)
                .build();
    }
}
