package com.microservices.order_service.dto.product;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.microservices.order_service.dto.order.OrderDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Data
@Builder
public class ProductDto implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;
    @Schema(description="Product Id", example="1" )
    private Integer productId;
    @Schema(description="Product Titel", example="Gaming accessories" )
    private String productTitle;
    @Schema(description="Product Img Url", example="https://products.com/product/game_accessories.jpeg" )
    private String imageUrl;
    @Schema(description="Product SKU Code", example="SKU82453" )
    private String sku;
    @Schema(description="Product Price", example="299.99" )
    private Double priceUnit;

    @Schema(description="Product Quantity", example="100" )
    private Integer quantity;

    // @Schema(description="Category Details", implementation = CategoryDto.class)
    @JsonProperty("category")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private CategoryDto categoryDto;

    // @Schema(description="Order Details", implementation = OrderDto.class)
    @JsonProperty("order")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private OrderDto orderDto;

}
