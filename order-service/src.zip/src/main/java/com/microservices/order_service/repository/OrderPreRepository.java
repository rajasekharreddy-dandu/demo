package com.microservices.order_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.microservices.order_service.entity.OrderPre;

@Repository
public interface OrderPreRepository extends JpaRepository<OrderPre, Long> {
    
}