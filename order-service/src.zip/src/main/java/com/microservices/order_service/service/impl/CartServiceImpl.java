package com.microservices.order_service.service.impl;

import com.microservices.order_service.dto.order.CartDto;
import com.microservices.order_service.dto.order.OrderDto;
import com.microservices.order_service.entity.Cart;
import com.microservices.order_service.entity.Order;
import com.microservices.order_service.exception.wrapper.CartNotFoundException;
import com.microservices.order_service.helper.CartMappingHelper;
import com.microservices.order_service.repository.CartRepository;
import com.microservices.order_service.repository.OrderRepository;
// import com.microservices.order_service.security.JwtTokenFilter;
import com.microservices.order_service.service.CartService;
import com.microservices.order_service.service.CallAPI;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.config.Configuration.AccessLevel;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private final CartRepository cartRepository;

    @Autowired
    private final OrderServiceImpl orderService;

    @Autowired
    private final OrderRepository orderRepository;

    @Autowired
    private final ModelMapper modelMapper;

    @Autowired
    private final CallAPI callAPI;

    @Override
    public Mono<List<CartDto>> findAll() {
        log.info("Cartservice; fetch all carts");

        return Mono.fromSupplier(() -> cartRepository.findAll()
                        .stream()
                        .map(CartMappingHelper::map)
                        .toList()
                );
                // .flatMap(cartDtos -> Flux.fromIterable(cartDtos)
                //         .flatMap(cartDto ->
                //                 callAPI.receiverUserDto(cartDto.getUserDto().getId(), JwtTokenFilter.getTokenFromRequest())
                //                         .map(userDto -> {
                //                             cartDto.setUserDto(userDto);
                //                             return cartDto;
                //                         })
                //                         .onErrorResume(throwable -> {
                //                             log.error("Error fetching user info: {}", throwable.getMessage());
                //                             return Mono.just(cartDto);
                //                         })
                //         ).collectList()
                // );
    }

    @Override
    public Mono<Page<CartDto>> findAll(int page, int size, String sortBy, String sortOrder) {
        log.info("CartDto List, service; fetch all carts with paging and sorting");
        Sort sort = Sort.by(Sort.Direction.fromString(sortOrder), sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);

        return Mono.fromSupplier(() -> cartRepository
                        .findAll(pageable)
                        .map(CartMappingHelper::map)
                        .toList()
                )
                        .map(resultList -> new PageImpl<>(resultList, pageable, resultList.size()));
                // .flatMap(cartDtos -> Flux.fromIterable(cartDtos)
                //         .flatMap(cartDto ->
                //                 callAPI.receiverUserDto(cartDto.getUserDto().getId(), JwtTokenFilter.getTokenFromRequest())
                //                         .map(userDto -> {
                //                             cartDto.setUserDto(userDto);
                //                             return cartDto;
                //                         })
                //                         .onErrorResume(throwable -> {
                //                             log.error("Error fetching user info: {}", throwable.getMessage());
                //                             return Mono.just(cartDto);
                //                         })
                //         )
                //         .collectList()
                //         .map(resultList -> new PageImpl<>(resultList, pageable, resultList.size()))
                // );
    }

    @Override
    public Mono<CartDto> findById(Integer cartId) {
       log.info("Cartservice; fetch cart by id");

        return Mono.fromSupplier(() -> cartRepository.findById(cartId)
                        .map(CartMappingHelper::map)
                        .orElseThrow(() -> new CartNotFoundException(String.format("Cart with id: %d not found", cartId)))
                );
                // .flatMap(cartDto ->
                //         callAPI.receiverUserDto(cartDto.getUserDto().getId(), JwtTokenFilter.getTokenFromRequest())
                //                 .map(userDto -> {
                //                     cartDto.setUserDto(userDto);
                //                     return cartDto;
                //                 })
                //                 .onErrorResume(throwable -> {
                //                     log.error("Error fetching user info: {}", throwable.getMessage());
                //                     return Mono.just(cartDto);
                //                 })
                // );
    }

    @Override
    public Mono<CartDto> save(final CartDto cartDto) {
        log.info("Cartservice , save cart");

        // return Mono.fromSupplier(() -> cartRepository.save(CartMappingHelper.map(cartDto)))
        //         .map(savedCart -> CartMappingHelper.map(savedCart));
    //    return Mono.fromSupplier(() -> {
    //         Cart cart = CartMappingHelper.map(cartDto);

    //         if (cart.getOrders() != null) {
    //             cart.getOrders().forEach(order -> order.setCart(cart));
    //         }

    //         return cartRepository.save(cart);
    //     }).map(savedCart -> CartMappingHelper.map(savedCart));
       
        return saveCartMono(cartDto);
    }

    @Override
    public Mono<CartDto> update(CartDto cartDto) {
        log.info("Cartservice; update cart");
        // return Mono.fromSupplier(() -> cartRepository.save(CartMappingHelper.map(cartDto)))
        //         .map(CartMappingHelper::map);
        // return Mono.fromSupplier(() -> {
        //     Cart cart = CartMappingHelper.map(cartDto);

        //     if (cart.getOrders() != null) {
        //         cart.getOrders().forEach(order -> order.setCart(cart));
        //     }

        //     return cartRepository.save(cart);
        // }).map(savedCart -> CartMappingHelper.map(savedCart));
        return saveCartMono(cartDto);
    }

    @Override
    public Mono<CartDto> update(Integer cartId, CartDto cartDto) {
       log.info("Cartservice; update cart with cartId");
        return findById(cartId).flatMap(existingCartDto -> {
            log.info("CartService: found existing cart with ID {}", existingCartDto);
            BeanUtils.copyProperties(cartDto, existingCartDto, "cartId");
                    // return Mono.fromSupplier(() -> {
                    //     Cart cart = CartMappingHelper.map(existingCartDto);
                    //     if (cart.getOrders() != null) {
                    //         cart.getOrders().forEach(order -> order.setCart(cart));
                    //     }
                    //     return cartRepository.save(cart);
                    // }).map(CartMappingHelper::map);
                    return saveCartMono(existingCartDto);
                            
                })
                .switchIfEmpty(Mono.error(new CartNotFoundException("Cart with id " + cartId + " not found")));
    }

    @Override
    public Mono<Void> deleteById(Integer cartId) {
        log.info("CartService: delete cart by id {}", cartId);
        cartRepository.findById(cartId)
                .ifPresent(cart -> {
                    if (cart.getOrders() != null && !cart.getOrders().isEmpty()) {
                        // Delete orders first, then cart
                        orderRepository.deleteAllByCart(cart);
                        log.info("CartService: deleted orders by cartId {}", cartId);
                    }
                    cartRepository.deleteById(cartId);
                    // orderRepository.deleteAllByCart(cart);
                    // cartRepository.deleteById(cartId);
                });
        return Mono.empty();
    }

    private Mono<CartDto> saveCartMono(final CartDto cartDto){
       return Mono.fromSupplier(() -> {
            Cart cart = CartMappingHelper.map(cartDto);
            if (cart.getOrders() != null) {
                cart.getOrders().forEach(order -> order.setCart(cart));
            }
            return cartRepository.save(cart);
        }).map(CartMappingHelper::map);
    }

   

}
