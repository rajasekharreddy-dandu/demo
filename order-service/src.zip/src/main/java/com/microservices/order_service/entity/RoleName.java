package com.microservices.order_service.entity;

public enum  RoleName {
    USER, PM, ADMIN
}
