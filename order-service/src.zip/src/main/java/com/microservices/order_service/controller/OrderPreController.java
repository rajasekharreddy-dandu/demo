package com.microservices.order_service.controller;

import java.util.concurrent.CompletableFuture;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.order_service.dto.OrderRequest;
import com.microservices.order_service.service.OrderPreService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import io.github.resilience4j.retry.annotation.Retry;

@RestController
@RequestMapping("/api/order")
@RequiredArgsConstructor
@Slf4j
public class OrderPreController {

    // private final OrderPreService orderPreService;

    // @PostMapping
    // // @ResponseStatus(HttpStatus.CREATED)
    // @CircuitBreaker(name = "inventory", fallbackMethod = "fallbackMethod")
    // @TimeLimiter(name = "inventory")
    // @Retry(name = "inventory")
    // public CompletableFuture<String> placeOrder(@RequestBody OrderRequest orderRequest){
    //     log.info("Placing Order");
    //     return CompletableFuture.supplyAsync(() -> orderPreService.placeOrder(orderRequest));
    // }

    // public CompletableFuture<String> fallbackMethod(OrderRequest orderRequest, RuntimeException runtimeException) {
    //     log.info("Cannot Place Order Executing Fallback logic");
    //     return CompletableFuture.supplyAsync(() -> "Oops! Something went wrong, please order after some time!");
    // }
}
